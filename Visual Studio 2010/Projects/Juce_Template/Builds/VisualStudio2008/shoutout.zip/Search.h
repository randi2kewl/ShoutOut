#ifndef __SEARCH_H
#define __SEARCH_H

#include "Account.h"
#include "../../JuceLibraryCode/JuceHeader.h"
#include "Dashboard.h"

class Search : public Component, public ButtonListener
{
public:
	Search(){}
	Search(Dashboard*);
	~Search(){ deleteAllChildren(); }

	void searchUserView();
	void searchUsers();

	void buttonClicked(Button *);

private:
	Label *menuLabel;
	TextButton *searchUsersButton;
	TextButton *searchShoutsButton;
	TextButton *uButton;
	TextEditor *username;
	TextButton *backButton;
	TextButton *followButton;

	Dashboard *dash;

	Account *searchedAccount;

};
#endif