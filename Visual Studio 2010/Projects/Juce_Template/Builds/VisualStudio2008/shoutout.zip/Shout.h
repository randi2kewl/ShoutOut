#ifndef __SHOUT_H
#define __SHOUT_H

#include <time.h>
#include <list>
#include <string>
#include "../../JuceLibraryCode/JuceHeader.h"
#include "Account.h"

class Account;

using namespace std;

class Shout
{
public:
	Shout(){}
	Shout(string, string, string, bool, time_t);
	~Shout(){}

	//accessors
	string getMessage() { return message; }
	string getSender() { return sender; }
	string getmMention() { return mention; }
	bool getIsPublic() { return isPublic; }
	time_t getDate() { return date; }


	//mutators
	void setIsPublic(bool pub) { isPublic = pub; } 


	//operations
	void createShout(String, Account*);

private:
	string message;
	string sender;
	string mention;
	bool isPublic;
	time_t date;
};
#endif