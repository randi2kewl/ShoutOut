#include "RoundCornerBox.h"

void RoundCornerBox::paint(Graphics& g)
{
	g.fillAll(Colours::white);
}