#ifndef __SORTLIST_H
#define __SORTLIST_H

#include "Account.h"

class Account;

class SortList
{
public:
	bool operator()(Account *lhv,Account *rhv) 
	{
	//	unsigned int i = 0;
	//while((i < lhv->getUsername().length()) && (i < rhv->getUsername().length()))
	//{
	//	if(tolower(lhv->getUsername()[i]) > tolower(rhv->getUsername()[i])) return true;
	//	else if(tolower(lhv->getUsername()[i]) > tolower(rhv->getUsername()[i])) return false;
	//	++i;
	//}
	//if(lhv->getUsername().length() < rhv->getUsername().length()) return true;
	//else return false;
		return lhv->getUsername() <  rhv->getUsername();
	}
};
#endif