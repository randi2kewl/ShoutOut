#include "ViewShouts.h"
#include "Account.h"
#include <list>

//ListBoxModel for creating the ListBox
class ShoutList : public ListBox, public ListBoxModel
{
public:

Dashboard *dash;//dashboard (contains the current accounts info)
list<Shout*> allShouts;
int val;

//constructor  to create the ListBox
ShoutList(Dashboard *dashboard) : ListBox("Shouts", 0)
{
	this->dash = dashboard;

	//create master list of shouts to be printed
	list<Account*>::iterator start, stop;
	start = dash->getAccountList()->begin();
	stop = dash->getAccountList()->end();

	for(; start != stop; ++start)
	{
		list<Shout*> temp = (*start)->getShoutList();

		list<Shout*>::iterator s_start, s_stop;
		s_start = temp.begin();
		s_stop = temp.end();

		for(; s_start != s_stop; ++s_start)
		{
			if((*s_start)->getmMention() == dash->getAccount()->getUsername() && (*s_start)->getIsPublic() == false)
			{
				allShouts.push_back((*s_start));
			}
			else if((*s_start)->getSender() == dash->getAccount()->getUsername() && (*s_start)->getIsPublic() == false)
			{
				allShouts.push_back((*s_start));
			}
			else if((*s_start)->getIsPublic() == true)
			{
				allShouts.push_back((*s_start));
			}
		}
	}


	setModel(this);

}//end constructor

~ShoutList(){  }

//returns the number of accounts in the follower list
int getNumRows()
{
	return allShouts.size();
}//end getNumRows

//prints the list onto the listbox
void paintListBoxItem(int rowNumber, Graphics& g, int width, int height, bool rowIsSelected)
{
	//highlight if selected
	if(rowIsSelected) 
	{
		g.fillAll(Colours::lightblue);
	}//end if

	//set font type and color
	g.setColour(Colours::black);
	g.setFont(height * 0.7f);

	//list<Shout*> temp = dash->getAccount()->getShoutList();

	list<Shout*>::iterator start, stop;
	start = allShouts.begin();

	advance(start, rowNumber);

	if((*start)->getSender() != "")
	{
		if(!(*start)->getIsPublic() && (*start)->getmMention() == dash->getAccount()->getUsername())
		{
			//draws the text
			g.setColour(Colours::red);
			g.drawText(String((*start)->getSender().append(" - ").append((*start)->getMessage()).c_str()), 5, 0, width, height, Justification::centredLeft, true);
		}
		else if(!(*start)->getIsPublic() && (*start)->getSender() == dash->getAccount()->getUsername())
		{
			//draws the text
			g.setColour(Colours::blue);
			g.drawText(String((*start)->getmMention().append(" - ").append((*start)->getMessage()).c_str()), 5, 0, width, height, Justification::centredLeft, true);
		}
		else //if((*start)->getIsPublic())
		{
			//draws the text
			g.setColour(Colours::black);
			g.drawText(String((*start)->getSender().append(" - ").append((*start)->getMessage()).c_str()), 5, 0, width, height, Justification::centredLeft, true);
		}
	}
}//end method paintListBoxItem

//paints the background behind the list
void paint(Graphics& g)
{
    g.fillAll(Colours::white.withAlpha(0.7f));
}//end method paint

void listBoxItemClicked(int row, const MouseEvent& e)
{
	list<Shout*>::iterator itr;
	itr = allShouts.begin();

	advance(itr, row);

	time_t temp = (*itr)->getDate();
	struct tm * timeinfo;
	char date[80];
	timeinfo = localtime( &temp );

	strftime(date, 80, "%c"  , timeinfo);

	std::string message = (*itr)->getSender() + "\n";
	message += date;
	message += "\n\n\"";

	if(!(*itr)->getIsPublic())
		message += "@" + (*itr)->getmMention() + " ";

	message += (*itr)->getMessage() + "\"";

	String shout(message.c_str());

   //val = row;
	AlertWindow::showMessageBoxAsync(AlertWindow::NoIcon, T("Shout:"),shout);
}
};//end class

ShoutList* lbox;//the listBox

//constructor takes in a dashboard and makes listbox visible
ViewShouts::ViewShouts(Dashboard* dashboard)
{
	this->dash = dashboard;

	lbox = new ShoutList(dash);
    addAndMakeVisible(lbox);
}//end constructor

//paint around the box (keeping clear to match the rest)
void ViewShouts::paint (Graphics& g)
{
   //g.fillAll (Colour (0xffa18a8a));
}//end method paint

void ViewShouts::resized()
{
	lbox->setBounds(0,0,400,250);
}

//tells what to do with button clicks
void ViewShouts::buttonClicked (Button* button)
{


}//end method buttonClicked