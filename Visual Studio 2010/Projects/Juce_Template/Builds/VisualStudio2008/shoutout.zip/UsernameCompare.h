#ifndef __USERNAMECOMPARE_H
#define __USERNAMECOMPARE_H

#include "Account.h"
#include "Search.h"

class UsernameCompare
{
public:
	bool operator()(const Account *lhv,const Account *rhv)
	{ 
		return lhv->getUsername() == rhv->getUsername();
	}
};
#endif