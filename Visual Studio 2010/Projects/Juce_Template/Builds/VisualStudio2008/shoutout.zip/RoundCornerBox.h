#ifndef ROUNDCORNERBOX_H
#define ROUNDCORNERBOX_H

#include "../../JuceLibraryCode/JuceHeader.h"
#include "ShoutComponent.h"

class ShoutComponent;

class RoundCornerBox : public Component
{
public:
	RoundCornerBox();
	~RoundCornerBox();

	void paint(Graphics& g);


private:

};
#endif