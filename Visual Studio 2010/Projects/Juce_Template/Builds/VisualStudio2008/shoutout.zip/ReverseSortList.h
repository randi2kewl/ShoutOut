#ifndef __REVERSESORTLIST_H
#define __REVERSESORTLIST_H

#include "Account.h"

class Account;

class ReverseSortList
{
public:
	bool operator()(Account *lhv,Account *rhv) 
	{
		return lhv->getUsername() >  rhv->getUsername();
	}
};
#endif