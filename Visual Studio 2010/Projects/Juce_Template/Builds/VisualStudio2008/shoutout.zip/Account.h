#ifndef __ACCOUNT_H
#define __ACCOUNT_H

#include <string>
#include "../../Source/MainWindow.h"
#include <algorithm>
#include <list>
#include "Shout.h"
#include <cctype>

using namespace std;

class Shout;

class Account 
{
public:
	Account();
	Account(string, string, string, string, string);
	~Account();

	//accessors
	string getUsername() const { return username; }
	string getPassword() const { return password;} 
	string getEmail() const { return email;}
	string getFirstName() const { return firstName; }
	string getLastName() const { return lastName; }
	
	int getFollowingCount() { return followingList.size(); }
	int getFollowerCount() { return followerList.size(); }
	
	void addFollowing(Account *);
	void addFollower(Account *);
	void removeFollowing (list<Account*>::iterator itr) { followingList.erase(itr); }
	void setFollowing(list<Account*> a) { followingList = a; }
	void setFollowerList(list<Account*> a) { followerList = a; }
	bool findUsernameMatch(Account*,string);
	Account* getAccount() { return this; }

	list<Account*> getFollowingList() { return followingList; }
	list<Account*> getFollowerList() { return followerList; }

	list<Shout*> getShoutList() { return shoutList; }

	Shout * getTempShout() { return tempShout; }

	void addShout(Shout *);
private:
	string username;
	string password;
	string email;
	string lastName;
	string firstName;

	Shout *tempShout;

	list<Shout*> shoutList;
	list<Account*> followingList;
	list<Account*> followerList;
};

#endif