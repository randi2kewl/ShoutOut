#ifndef __MAINCOMPONENT_H
#define __MAINCOMPONENT_H

#include "../../Source/MainWindow.h"
#include "Dashboard.h"
#include "Account.h"
#include <list>


class MainComponent : public Component , public ButtonListener
{
public:

	//constructor
	MainComponent(list<Account*>*);
	
	//destructor
	~MainComponent();

	//operations
	void errorMessage(String error);

	//required operations
	void buttonClicked(Button *);

private:
	TextButton *loginButton;
	TextButton *createAcctButton;
	Label *instructLabel;
	TextEditor *uname;
	TextEditor *pass;
	Label *usernameLabel;
	Label *passwordLabel;

	list<Account*> *acctList;

};
#endif