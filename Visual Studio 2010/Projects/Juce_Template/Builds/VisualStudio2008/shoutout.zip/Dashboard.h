#ifndef __DASHBOARD_H
#define __DASHBOARD_H

#include "Account.h"
#include "../../JuceLibraryCode/JuceHeader.h"
#include "MainComponent.h"
#include <list>

class Account;

class Dashboard : public Component, public ButtonListener
{
public:
	Dashboard();
	Dashboard(Account*, list<Account*>*);
	~Dashboard(){ deleteAllChildren(); }

	list<Account*> * getAccountList() { return acctList; }
	Account * getAccount() { return acct; }


	void updateFollowingCount();

	void buttonClicked(Button*);

	Button * getLogoutButton() { return logoutButton; }

private:
	Component *container;

	Label *welcome;
	TextButton *logoutButton;
	Label *followerCountLabel;
	Label *followingCountLabel;
	Label *newShoutLabel;
	TextButton *mainMenuButton;
	TextButton *shoutButton;

	list<Account*> *acctList;
	Account *acct;

};
#endif